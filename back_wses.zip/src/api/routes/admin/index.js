module.exports = require('./admin.route'); //exporting super auth routes
